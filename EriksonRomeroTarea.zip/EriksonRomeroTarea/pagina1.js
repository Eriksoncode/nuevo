let menuPrincipal = document.getElementById('menu-principal');
let menuContenedor = document.getElementById('contenedor-menu');

// 1; función
menuPrincipal.addEventListener('click', function() {
  this.classList.toggle('active');
  menuContenedor.classList.toggle('active');
});

// 2; función 
document.addEventListener('click', function(event) {
  let targetElement = event.target;
  if (!targetElement.closest('#menu-principal') && !targetElement.closest('#contenedor-menu')) {
    menuPrincipal.classList.remove('active');
    menuContenedor.classList.remove('active');
  }
});

